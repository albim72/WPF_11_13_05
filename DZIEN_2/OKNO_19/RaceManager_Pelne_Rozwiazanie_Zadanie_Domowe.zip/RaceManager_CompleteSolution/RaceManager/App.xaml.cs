using System.Windows;

namespace RaceManager;

public partial class App : Application
{
}
