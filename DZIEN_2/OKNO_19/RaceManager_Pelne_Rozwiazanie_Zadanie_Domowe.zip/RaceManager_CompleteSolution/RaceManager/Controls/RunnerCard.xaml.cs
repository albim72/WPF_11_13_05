using System.Windows;
using System.Windows.Controls;

namespace RaceManager.Controls;

public partial class RunnerCard : UserControl
{
    public static readonly DependencyProperty RunnerNameProperty =
        DependencyProperty.Register(
            nameof(RunnerName),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty DistanceProperty =
        DependencyProperty.Register(
            nameof(Distance),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty StatusProperty =
        DependencyProperty.Register(
            nameof(Status),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata(string.Empty));

    public string RunnerName
    {
        get => (string)GetValue(RunnerNameProperty);
        set => SetValue(RunnerNameProperty, value);
    }

    public string Distance
    {
        get => (string)GetValue(DistanceProperty);
        set => SetValue(DistanceProperty, value);
    }

    public string Status
    {
        get => (string)GetValue(StatusProperty);
        set => SetValue(StatusProperty, value);
    }

    public RunnerCard()
    {
        InitializeComponent();
    }
}
