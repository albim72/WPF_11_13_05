using System.Windows;
using RaceManager.ViewModels;

namespace RaceManager;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
