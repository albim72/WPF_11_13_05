using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using RaceManager.Commands;
using RaceManager.Models;

namespace RaceManager.ViewModels;

public class MainViewModel : INotifyPropertyChanged
{
    private string _firstName = string.Empty;
    private string _lastName = string.Empty;
    private string? _selectedDistance;
    private string? _selectedStatus;
    private Runner? _selectedRunner;

    public ObservableCollection<Runner> Runners { get; } = new();

    public ObservableCollection<string> Distances { get; } = new()
    {
        "5 km",
        "10 km",
        "21 km",
        "42 km",
        "Trail 33 km",
        "Ultra 50 km"
    };

    public ObservableCollection<string> Statuses { get; } = new()
    {
        "OK",
        "WARNING",
        "DNF",
        "DNS"
    };

    public string FirstName
    {
        get => _firstName;
        set
        {
            if (_firstName == value) return;
            _firstName = value;
            OnPropertyChanged();
        }
    }

    public string LastName
    {
        get => _lastName;
        set
        {
            if (_lastName == value) return;
            _lastName = value;
            OnPropertyChanged();
        }
    }

    public string? SelectedDistance
    {
        get => _selectedDistance;
        set
        {
            if (_selectedDistance == value) return;
            _selectedDistance = value;
            OnPropertyChanged();
        }
    }

    public string? SelectedStatus
    {
        get => _selectedStatus;
        set
        {
            if (_selectedStatus == value) return;
            _selectedStatus = value;
            OnPropertyChanged();
        }
    }

    public Runner? SelectedRunner
    {
        get => _selectedRunner;
        set
        {
            if (_selectedRunner == value) return;
            _selectedRunner = value;
            OnPropertyChanged();
        }
    }

    public ICommand AddRunnerCommand { get; }
    public ICommand RemoveRunnerCommand { get; }

    public MainViewModel()
    {
        SelectedDistance = Distances[2];
        SelectedStatus = Statuses[0];

        AddRunnerCommand = new RelayCommand(_ => AddRunner());
        RemoveRunnerCommand = new RelayCommand(_ => RemoveSelectedRunner());

        LoadSampleData();
    }

    private void LoadSampleData()
    {
        Runners.Add(new Runner { FirstName = "Anna", LastName = "Nowak", Distance = "Trail 33 km", Status = "OK" });
        Runners.Add(new Runner { FirstName = "Piotr", LastName = "Zieliński", Distance = "Ultra 50 km", Status = "WARNING" });
        Runners.Add(new Runner { FirstName = "Maria", LastName = "Lis", Distance = "10 km", Status = "DNS" });
        Runners.Add(new Runner { FirstName = "Tomasz", LastName = "Wójcik", Distance = "42 km", Status = "DNF" });
    }

    private void AddRunner()
    {
        if (string.IsNullOrWhiteSpace(FirstName) ||
            string.IsNullOrWhiteSpace(LastName) ||
            string.IsNullOrWhiteSpace(SelectedDistance) ||
            string.IsNullOrWhiteSpace(SelectedStatus))
        {
            MessageBox.Show(
                "Uzupełnij wszystkie dane zawodnika.",
                "Brak danych",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        var runner = new Runner
        {
            FirstName = FirstName.Trim(),
            LastName = LastName.Trim(),
            Distance = SelectedDistance,
            Status = SelectedStatus
        };

        Runners.Add(runner);
        SelectedRunner = runner;

        FirstName = string.Empty;
        LastName = string.Empty;
        SelectedDistance = Distances[0];
        SelectedStatus = Statuses[0];
    }

    private void RemoveSelectedRunner()
    {
        if (SelectedRunner == null)
        {
            MessageBox.Show(
                "Wybierz zawodnika do usunięcia.",
                "Brak zaznaczenia",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        Runners.Remove(SelectedRunner);
        SelectedRunner = null;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
