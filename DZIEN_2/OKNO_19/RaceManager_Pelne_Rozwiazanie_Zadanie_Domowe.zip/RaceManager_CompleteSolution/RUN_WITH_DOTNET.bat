@echo off
cd /d "%~dp0"
dotnet run --project RaceManager\RaceManager.csproj
pause
