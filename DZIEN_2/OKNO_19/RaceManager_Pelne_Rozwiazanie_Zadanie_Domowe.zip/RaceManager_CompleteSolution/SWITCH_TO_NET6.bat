@echo off
powershell -ExecutionPolicy Bypass -Command "(Get-Content 'RaceManager\RaceManager.csproj') -replace 'net8.0-windows','net6.0-windows' | Set-Content 'RaceManager\RaceManager.csproj'"
echo Projekt przestawiony na net6.0-windows.
pause
