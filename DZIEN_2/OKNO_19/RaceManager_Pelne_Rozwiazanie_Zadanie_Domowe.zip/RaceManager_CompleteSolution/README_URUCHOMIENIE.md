# RaceManager - pełne rozwiązanie zadania domowego WPF

Projekt zawiera kompletne rozwiązanie zadania: **Panel zawodów biegowych w WPF**.

## Jak uruchomić

### Sposób 1: Visual Studio

1. Rozpakuj ZIP.
2. Otwórz plik `RaceManager.sln`.
3. W Visual Studio wybierz: `Kompilowanie -> Kompiluj rozwiązanie` albo `Ctrl + Shift + B`.
4. Uruchom aplikację klawiszem `F5` albo `Ctrl + F5`.

### Sposób 2: plik BAT

Uruchom:

```text
OPEN_IN_VISUAL_STUDIO.bat
```

albo:

```text
RUN_WITH_DOTNET.bat
```

## Wersja .NET

Domyślnie projekt jest ustawiony na:

```xml
<TargetFramework>net8.0-windows</TargetFramework>
```

Jeżeli komputer szkoleniowy ma tylko .NET 6, uruchom:

```text
SWITCH_TO_NET6.bat
```

albo ręcznie zmień w pliku `RaceManager.csproj` wartość `net8.0-windows` na `net6.0-windows`.

## Co zawiera rozwiązanie

- aplikację WPF `RaceManager`,
- model `Runner`,
- `ObservableCollection<Runner>`,
- formularz dodawania zawodnika,
- listę dystansów w `ComboBox`,
- listę statusów w `ComboBox`,
- walidację danych,
- dodawanie zawodnika,
- usuwanie zaznaczonego zawodnika,
- `ListBox` z własnym `DataTemplate`,
- własną kontrolkę użytkownika `RunnerCard`,
- `DependencyProperty` dla danych kontrolki,
- style przez `StaticResource`,
- własny `ControlTemplate` dla przycisku,
- różne kolory statusów przez `DataTrigger`,
- komunikat z liczbą zawodników,
- przykładowe dane startowe.

## Struktura projektu

```text
RaceManager
│
├── App.xaml
├── MainWindow.xaml
├── MainWindow.xaml.cs
│
├── Models
│   └── Runner.cs
│
├── ViewModels
│   └── MainViewModel.cs
│
├── Commands
│   └── RelayCommand.cs
│
└── Controls
    ├── RunnerCard.xaml
    └── RunnerCard.xaml.cs
```

## Elementy dla chętnych / wersja rozszerzona

W projekcie zrobiono również elementy rozszerzone:

1. `RunnerCard` jako własny `UserControl`.
2. `DependencyProperty`: `RunnerName`, `Distance`, `Status`.
3. Użycie `RunnerCard` wewnątrz `DataTemplate` dla `ListBox`.
4. Własny `ControlTemplate` dla przycisków.
5. Kolory statusów:
   - `OK` - zielony,
   - `WARNING` - pomarańczowy,
   - `DNF` - czerwony,
   - `DNS` - szary.
6. Licznik zawodników na dole okna.
7. Osobny styl kart zawodników.
8. Estetyczny układ całego okna.

## Gdzie są najważniejsze mechanizmy

- `ObservableCollection` znajduje się w `ViewModels/MainViewModel.cs`.
- `Binding` formularza znajduje się w `MainWindow.xaml`.
- `DataTemplate` znajduje się w `MainWindow.xaml`.
- `RunnerCard` znajduje się w folderze `Controls`.
- `DependencyProperty` znajduje się w `Controls/RunnerCard.xaml.cs`.
- Style i `StaticResource` znajdują się w `App.xaml`.
- `ControlTemplate` przycisku znajduje się w `App.xaml`.
- Kolory statusów przez `DataTrigger` znajdują się w `Controls/RunnerCard.xaml`.
