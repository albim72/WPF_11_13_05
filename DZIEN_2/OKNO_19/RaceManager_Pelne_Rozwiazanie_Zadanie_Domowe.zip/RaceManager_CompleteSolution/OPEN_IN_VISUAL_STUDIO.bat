@echo off
start "" "%~dp0RaceManager.sln"
