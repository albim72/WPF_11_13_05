﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lista_extended
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel = new();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = _viewModel;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string firstName = FirstNameTextBox.Text.Trim();
            string lastName = LastNameTextBox.Text.Trim();
            string distance = _viewModel.SelectedDistance.Trim();

            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Podaj imię i nazwisko zawodnika.", "Brak danych", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(distance))
            {
                MessageBox.Show("Wybierz dystans biegu.", "Brak dystansu", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _viewModel.Runners.Add(new Runner(firstName, lastName, distance));

            FirstNameTextBox.Clear();
            LastNameTextBox.Clear();
            FirstNameTextBox.Focus();
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_viewModel.SelectedRunner is null)
            {
                MessageBox.Show("Zaznacz zawodnika, którego chcesz usunąć.", "Brak zaznaczenia", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Runner runnerToRemove = _viewModel.SelectedRunner;
            _viewModel.Runners.Remove(runnerToRemove);
            _viewModel.SelectedRunner = null;
        }

        
    }

    public class MainViewModel : INotifyPropertyChanged
    {
        private string _selectedDistance;
        private Runner? _selectedRunner;

        public MainViewModel()
        {
            _selectedDistance = Distances[0];
        }

        public ObservableCollection<Runner> Runners { get; } = new()
    {
        new Runner("Anna", "Nowak", "21 km"),
        new Runner("Piotr", "Zieliński", "Ultra 50 km")
    };

        public List<string> Distances { get; } = new()
    {
        "5 km",
        "10 km",
        "21 km",
        "42 km",
        "Ultra 50 km"
    };

        public string SelectedDistance
        {
            get => _selectedDistance;
            set
            {
                if (_selectedDistance == value) return;
                _selectedDistance = value;
                OnPropertyChanged();
            }
        }

        public Runner? SelectedRunner
        {
            get => _selectedRunner;
            set
            {
                if (_selectedRunner == value) return;
                _selectedRunner = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class Runner
    {
        public Runner(string firstName, string lastName, string distance)
        {
            FirstName = firstName;
            LastName = lastName;
            Distance = distance;
        }

        public string FirstName { get; }
        public string LastName { get; }
        public string Distance { get; }

        public string DisplayName => $"{FirstName} {LastName} - {Distance}";
    }

}
