@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo  WPF - Zadanie 11 - UserControl RunnerCard
echo ============================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
    echo Nie znaleziono polecenia dotnet.
    echo Zainstaluj .NET SDK 8.0 lub nowszy:
    echo https://dotnet.microsoft.com/download
    echo.
    pause
    exit /b 1
)

echo Przywracanie pakietow...
dotnet restore
if errorlevel 1 goto error

echo.
echo Budowanie projektu...
dotnet build
if errorlevel 1 goto error

echo.
echo Uruchamianie aplikacji...
dotnet run
if errorlevel 1 goto error

goto end

:error
echo.
echo Wystapil blad podczas budowania albo uruchamiania projektu.
echo Sprawdz komunikaty powyzej.
pause
exit /b 1

:end
echo.
echo Gotowe.
pause
