using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfDay2Exercise11.Controls;

public partial class RunnerCard : UserControl
{
    public RunnerCard()
    {
        InitializeComponent();
    }

    public string RunnerName
    {
        get => (string)GetValue(RunnerNameProperty);
        set => SetValue(RunnerNameProperty, value);
    }

    public static readonly DependencyProperty RunnerNameProperty =
        DependencyProperty.Register(
            nameof(RunnerName),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("Brak imienia"));

    public string RaceName
    {
        get => (string)GetValue(RaceNameProperty);
        set => SetValue(RaceNameProperty, value);
    }

    public static readonly DependencyProperty RaceNameProperty =
        DependencyProperty.Register(
            nameof(RaceName),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("Brak nazwy zawodów"));

    public string Distance
    {
        get => (string)GetValue(DistanceProperty);
        set => SetValue(DistanceProperty, value);
    }

    public static readonly DependencyProperty DistanceProperty =
        DependencyProperty.Register(
            nameof(Distance),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("0 km"));

    public string Elevation
    {
        get => (string)GetValue(ElevationProperty);
        set => SetValue(ElevationProperty, value);
    }

    public static readonly DependencyProperty ElevationProperty =
        DependencyProperty.Register(
            nameof(Elevation),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("0 m+"));

    public string Pace
    {
        get => (string)GetValue(PaceProperty);
        set => SetValue(PaceProperty, value);
    }

    public static readonly DependencyProperty PaceProperty =
        DependencyProperty.Register(
            nameof(Pace),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("--"));

    public string Status
    {
        get => (string)GetValue(StatusProperty);
        set => SetValue(StatusProperty, value);
    }

    public static readonly DependencyProperty StatusProperty =
        DependencyProperty.Register(
            nameof(Status),
            typeof(string),
            typeof(RunnerCard),
            new PropertyMetadata("BRAK"));

    public int BibNumber
    {
        get => (int)GetValue(BibNumberProperty);
        set => SetValue(BibNumberProperty, value);
    }

    public static readonly DependencyProperty BibNumberProperty =
        DependencyProperty.Register(
            nameof(BibNumber),
            typeof(int),
            typeof(RunnerCard),
            new PropertyMetadata(0));

    public Brush AccentBrush
    {
        get => (Brush)GetValue(AccentBrushProperty);
        set => SetValue(AccentBrushProperty, value);
    }

    public static readonly DependencyProperty AccentBrushProperty =
        DependencyProperty.Register(
            nameof(AccentBrush),
            typeof(Brush),
            typeof(RunnerCard),
            new PropertyMetadata(Brushes.SteelBlue));

    public Brush StatusBackground
    {
        get => (Brush)GetValue(StatusBackgroundProperty);
        set => SetValue(StatusBackgroundProperty, value);
    }

    public static readonly DependencyProperty StatusBackgroundProperty =
        DependencyProperty.Register(
            nameof(StatusBackground),
            typeof(Brush),
            typeof(RunnerCard),
            new PropertyMetadata(Brushes.LightGray));

    public Brush StatusForeground
    {
        get => (Brush)GetValue(StatusForegroundProperty);
        set => SetValue(StatusForegroundProperty, value);
    }

    public static readonly DependencyProperty StatusForegroundProperty =
        DependencyProperty.Register(
            nameof(StatusForeground),
            typeof(Brush),
            typeof(RunnerCard),
            new PropertyMetadata(Brushes.Black));
}
