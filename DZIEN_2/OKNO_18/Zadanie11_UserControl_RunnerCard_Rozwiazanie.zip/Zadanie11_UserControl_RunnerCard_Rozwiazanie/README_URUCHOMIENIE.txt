ZADANIE 11 - PEŁNE ROZWIĄZANIE DO URUCHOMIENIA
UserControl: własna karta zawodnika RunnerCard

WYMAGANIA
1. Windows 10/11
2. .NET SDK 8.0 lub nowszy
3. Visual Studio 2022 albo Visual Studio Code z terminalem

JAK URUCHOMIĆ - NAJPROŚCIEJ
1. Rozpakuj ZIP.
2. Wejdź do folderu projektu.
3. Kliknij dwukrotnie RUN.bat.

JAK URUCHOMIĆ Z TERMINALA
1. Otwórz PowerShell lub CMD w folderze projektu.
2. Wpisz:

   dotnet restore
   dotnet build
   dotnet run

JAK URUCHOMIĆ W VISUAL STUDIO
1. Otwórz plik WpfDay2Exercise11.csproj albo WpfDay2Exercise11.sln.
2. Poczekaj, aż Visual Studio przywróci zależności.
3. Naciśnij F5 albo Ctrl+F5.

CO POKAZUJE ROZWIĄZANIE
- utworzenie własnej kontrolki WPF: Controls/RunnerCard.xaml,
- dodanie DependencyProperty w RunnerCard.xaml.cs,
- przekazywanie parametrów do kontrolki z poziomu MainWindow.xaml,
- wielokrotne użycie tej samej kontrolki dla różnych zawodników,
- wiązanie danych w UserControl przez ElementName=root,
- przekazywanie tekstów, liczb i kolorów jako właściwości kontrolki.

NAJWAŻNIEJSZE PLIKI
- MainWindow.xaml                  - główne okno z listą kart zawodników
- Controls/RunnerCard.xaml         - wygląd własnej kontrolki
- Controls/RunnerCard.xaml.cs      - DependencyProperty kontrolki
- WpfDay2Exercise11.csproj         - projekt WPF dla .NET 8
- RUN.bat                          - szybkie uruchomienie projektu

UWAGA
WPF działa natywnie na Windows. Na Linux/macOS projekt może się nie uruchomić, nawet jeśli jest zainstalowany .NET SDK, ponieważ WPF jest technologią desktopową Windows.
