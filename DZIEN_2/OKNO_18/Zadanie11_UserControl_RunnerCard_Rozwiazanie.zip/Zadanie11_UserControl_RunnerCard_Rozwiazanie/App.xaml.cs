using System.Windows;

namespace WpfDay2Exercise11;

public partial class App : Application
{
}
