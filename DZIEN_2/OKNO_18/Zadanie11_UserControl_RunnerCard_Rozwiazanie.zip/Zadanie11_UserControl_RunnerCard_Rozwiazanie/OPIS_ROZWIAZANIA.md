# Zadanie 11 - UserControl: własna karta zawodnika

## Cel ćwiczenia

Celem ćwiczenia jest pokazanie, jak wydzielić fragment interfejsu do osobnej kontrolki WPF typu `UserControl`, a następnie użyć jej wielokrotnie w głównym oknie aplikacji.

W tym rozwiązaniu kontrolka `RunnerCard` reprezentuje kartę zawodnika startującego w biegu. Każda karta może mieć inne dane: imię i nazwisko, nazwę biegu, dystans, przewyższenie, tempo, status, numer startowy oraz kolory.

## Struktura projektu

```text
Zadanie11_UserControl_RunnerCard_Rozwiazanie/
│
├── App.xaml
├── App.xaml.cs
├── MainWindow.xaml
├── MainWindow.xaml.cs
├── WpfDay2Exercise11.csproj
├── WpfDay2Exercise11.sln
│
└── Controls/
    ├── RunnerCard.xaml
    └── RunnerCard.xaml.cs
```

## Najważniejszy mechanizm

W pliku `RunnerCard.xaml.cs` zdefiniowano właściwości zależne, czyli `DependencyProperty`. Dzięki nim można przekazywać dane bezpośrednio z XAML-a:

```xml
<controls:RunnerCard RunnerName="Anna Nowak"
                     RaceName="Pieniny Ultra Trail"
                     Distance="33 km"
                     Status="GOTOWA" />
```

Wewnątrz kontrolki dane są odczytywane przez binding do elementu głównego:

```xml
Text="{Binding RunnerName, ElementName=root}"
```

To ważne, ponieważ `UserControl` często bywa używany wewnątrz większych struktur, gdzie `DataContext` może pochodzić z zewnątrz. Wiązanie przez `ElementName=root` jest czytelne i stabilne dydaktycznie.

## Co kursant powinien zrozumieć

1. `UserControl` pozwala budować własne elementy interfejsu.
2. `DependencyProperty` pozwala przekazywać parametry do kontrolki z XAML-a.
3. Ta sama kontrolka może być użyta wiele razy z różnymi wartościami.
4. Kontrolka może przyjmować nie tylko tekst, lecz także liczby i kolory.
5. `ElementName=root` pozwala wiązać elementy wewnątrz kontrolki z jej własnymi właściwościami.

## Propozycja rozszerzenia dla chętnych

Można dodać:

- ikonę statusu,
- kliknięcie w kartę i pokazanie szczegółów zawodnika,
- kolekcję `ObservableCollection<Runner>` i generowanie kart przez `ItemsControl`,
- konwerter statusu na kolor,
- tryb zaznaczenia aktywnej karty.
