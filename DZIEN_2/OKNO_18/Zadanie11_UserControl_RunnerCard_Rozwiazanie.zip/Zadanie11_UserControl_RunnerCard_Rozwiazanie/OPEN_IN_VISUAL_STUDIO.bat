@echo off
cd /d "%~dp0"
start "" "WpfDay2Exercise11.csproj"
