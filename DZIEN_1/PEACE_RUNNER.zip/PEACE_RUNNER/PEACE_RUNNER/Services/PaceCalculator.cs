using RunnerPaceCalculator.Models;
using System;

namespace RunnerPaceCalculator.Services;

public static class PaceCalculator
{
    private const double MilesToKilometers = 1.609344;

    public static PaceResult Calculate(double distance, int hours, int minutes, DistanceUnit unit)
    {
        if (distance <= 0)
            throw new ArgumentException("Dystans musi być większy od zera.");

        if (hours < 0)
            throw new ArgumentException("Liczba godzin nie może być ujemna.");

        if (minutes < 0 || minutes >= 60)
            throw new ArgumentException("Minuty muszą być liczbą od 0 do 59.");

        int totalMinutes = hours * 60 + minutes;

        if (totalMinutes <= 0)
            throw new ArgumentException("Całkowity czas biegu musi być większy od zera.");

        double paceInSelectedUnit = totalMinutes / distance;
        double distanceInKilometers = unit == DistanceUnit.Kilometers
            ? distance
            : distance * MilesToKilometers;
        double pacePerKilometer = totalMinutes / distanceInKilometers;

        return new PaceResult
        {
            Distance = distance,
            Unit = unit,
            TotalMinutes = totalMinutes,
            PaceInSelectedUnit = paceInSelectedUnit,
            PacePerKilometer = pacePerKilometer,
            Category = GetCategory(pacePerKilometer)
        };
    }

    private static PaceCategory GetCategory(double pacePerKilometer)
    {
        if (pacePerKilometer < 5.0)
            return PaceCategory.Fast;

        if (pacePerKilometer <= 6.5)
            return PaceCategory.Training;

        return PaceCategory.Recreational;
    }
}
