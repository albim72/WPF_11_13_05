using System.Windows;

namespace RunnerPaceCalculator;

public partial class App : Application
{
}
