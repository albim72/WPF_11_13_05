using System.Globalization;
using System.Windows;
using System.Windows.Media;
using RunnerPaceCalculator.Models;
using RunnerPaceCalculator.Services;

namespace RunnerPaceCalculator;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void CalculateButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            double distance = ParseDistance(DistanceTextBox.Text);
            int hours = ParseInteger(HoursTextBox.Text, "godziny");
            int minutes = ParseInteger(MinutesTextBox.Text, "minuty");
            DistanceUnit unit = GetSelectedDistanceUnit();

            PaceResult result = PaceCalculator.Calculate(distance, hours, minutes, unit);
            ShowResult(result);
        }
        catch (Exception ex)
        {
            ShowError(ex.Message);
        }
    }

    private static double ParseDistance(string text)
    {
        string normalizedText = text.Trim().Replace(',', '.');

        bool isCorrect = double.TryParse(
            normalizedText,
            NumberStyles.Number,
            CultureInfo.InvariantCulture,
            out double value);

        if (!isCorrect)
            throw new ArgumentException("Dystans musi być poprawną liczbą, np. 10 albo 21,1.");

        return value;
    }

    private static int ParseInteger(string text, string fieldName)
    {
        bool isCorrect = int.TryParse(text.Trim(), out int value);

        if (!isCorrect)
            throw new ArgumentException($"Pole '{fieldName}' musi zawierać poprawną liczbę całkowitą.");

        return value;
    }

    private DistanceUnit GetSelectedDistanceUnit()
    {
        if (DistanceUnitComboBox.SelectedIndex == 1)
            return DistanceUnit.Miles;

        return DistanceUnit.Kilometers;
    }

    private void ShowResult(PaceResult result)
    {
        string formattedPace = FormatPace(result.PaceInSelectedUnit);
        string selectedUnitResult = $"Średnie tempo: {formattedPace} {result.UnitLabel}";

        if (result.Unit == DistanceUnit.Miles)
        {
            selectedUnitResult += $"  |  czyli około {FormatPace(result.PacePerKilometer)} min/km";
        }

        ResultTextBlock.Text = selectedUnitResult;
        ResultTextBlock.Foreground = GetBrushForPace(result.PacePerKilometer);
        CategoryTextBlock.Text = GetCategoryDescription(result.Category);
    }

    private static string FormatPace(double pace)
    {
        int minutes = (int)Math.Floor(pace);
        int seconds = (int)Math.Round((pace - minutes) * 60);

        if (seconds == 60)
        {
            minutes++;
            seconds = 0;
        }

        return $"{minutes}:{seconds:00}";
    }

    private static Brush GetBrushForPace(double pacePerKilometer)
    {
        if (pacePerKilometer < 5.0)
            return Brushes.Green;

        if (pacePerKilometer <= 6.5)
            return Brushes.Orange;

        return Brushes.Red;
    }

    private static string GetCategoryDescription(PaceCategory category)
    {
        return category switch
        {
            PaceCategory.Fast => "Tempo szybkie: to już biegowy ogień w butach. Dobre dla mocnych akcentów albo zawodów.",
            PaceCategory.Training => "Tempo treningowe: solidny, kontrolowany rytm do budowania formy.",
            _ => "Tempo rekreacyjne: spokojne, dobre na luźny bieg, rozbieganie albo powrót po przerwie."
        };
    }

    private void ShowError(string message)
    {
        ResultTextBlock.Text = "Błąd danych";
        ResultTextBlock.Foreground = Brushes.Red;
        CategoryTextBlock.Text = message;
    }

    private void ClearButton_Click(object sender, RoutedEventArgs e)
    {
        DistanceTextBox.Clear();
        HoursTextBox.Clear();
        MinutesTextBox.Clear();
        DistanceUnitComboBox.SelectedIndex = 0;
        ResultTextBlock.Text = "Średnie tempo pojawi się tutaj.";
        ResultTextBlock.Foreground = new SolidColorBrush(Color.FromRgb(96, 112, 135));
        CategoryTextBlock.Text = string.Empty;
        DistanceTextBox.Focus();
    }
}
