namespace RunnerPaceCalculator.Models;

public enum DistanceUnit
{
    Kilometers,
    Miles
}
