namespace RunnerPaceCalculator.Models;

public enum PaceCategory
{
    Fast,
    Training,
    Recreational
}
