namespace RunnerPaceCalculator.Models;

public class PaceResult
{
    public double Distance { get; set; }
    public DistanceUnit Unit { get; set; }
    public int TotalMinutes { get; set; }
    public double PaceInSelectedUnit { get; set; }
    public double PacePerKilometer { get; set; }
    public PaceCategory Category { get; set; }

    public string UnitLabel => Unit == DistanceUnit.Kilometers ? "min/km" : "min/milę";
}
