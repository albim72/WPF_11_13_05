# RunnerPaceCalculator | WPF | Kalkulator tempa biegacza

Pełne rozwiązanie zadania domowego WPF: proste okno z obliczeniem średniego tempa biegacza.

Projekt zawiera również wszystkie elementy z sekcji **zadania dodatkowe dla chętnych**:

- wybór jednostki dystansu: kilometry albo mile,
- zmianę koloru wyniku zależnie od tempa,
- przycisk **Wyczyść**,
- krótką informację tekstową: tempo szybkie, treningowe albo rekreacyjne.

## Jak uruchomić projekt

1. Rozpakuj plik ZIP.
2. Otwórz plik `RunnerPaceCalculator.sln` w Visual Studio 2022.
3. Upewnij się, że masz zainstalowany workload: **.NET desktop development**.
4. Uruchom projekt klawiszem `F5` albo przyciskiem **Start**.

Projekt jest przygotowany dla:

- .NET 8,
- WPF,
- C#,
- XAML.

## Struktura projektu

```text
RunnerPaceCalculator/
├── RunnerPaceCalculator.sln
├── README.md
└── RunnerPaceCalculator/
    ├── RunnerPaceCalculator.csproj
    ├── App.xaml
    ├── App.xaml.cs
    ├── MainWindow.xaml
    ├── MainWindow.xaml.cs
    ├── Models/
    │   ├── DistanceUnit.cs
    │   ├── PaceCategory.cs
    │   └── PaceResult.cs
    └── Services/
        └── PaceCalculator.cs
```

## Najważniejsze pliki

### `MainWindow.xaml`

Zawiera interfejs aplikacji:

- pola tekstowe na dystans, godziny i minuty,
- listę wyboru jednostki dystansu,
- przyciski **Oblicz tempo** i **Wyczyść**,
- miejsce na wynik,
- informację o zadaniach dodatkowych.

### `MainWindow.xaml.cs`

Zawiera obsługę zdarzeń:

- kliknięcie przycisku **Oblicz tempo**,
- walidację danych wejściowych,
- formatowanie wyniku do postaci `minuty:sekundy`,
- dobór koloru wyniku,
- komunikaty błędów,
- czyszczenie formularza.

### `Services/PaceCalculator.cs`

Zawiera logikę obliczeń. Dzięki temu najważniejszy algorytm nie jest ukryty w kodzie okna.

## Zasada obliczenia

```text
średnie tempo = całkowity czas biegu w minutach / dystans
```

Przykład:

```text
Dystans: 10 km
Czas: 0 godzin i 55 minut
Tempo: 55 / 10 = 5,5 min/km
Wynik: 5:30 min/km
```

## Testy ręczne

| Dystans | Jednostka | Godziny | Minuty | Oczekiwany wynik |
|---:|:---|---:|---:|:---|
| 10 | km | 0 | 55 | 5:30 min/km |
| 21,1 | km | 1 | 50 | około 5:13 min/km |
| 5 | km | 0 | 25 | 5:00 min/km |
| 42,195 | km | 4 | 0 | około 5:41 min/km |
| 10 | mile | 1 | 20 | 8:00 min/milę oraz około 4:58 min/km |

## Reguły kolorów

Kolor wyniku liczony jest według tempa w przeliczeniu na kilometry:

- zielony: poniżej `5:00 min/km`,
- pomarańczowy: od `5:00` do `6:30 min/km`,
- czerwony: powyżej `6:30 min/km`.

## Uwaga dydaktyczna

Projekt celowo nie używa MVVM. To rozwiązanie dla początkujących, więc pokazuje prostą, czytelną ścieżkę:

1. odczytaj tekst z pól,
2. sprawdź poprawność danych,
3. wykonaj obliczenie,
4. sformatuj wynik,
5. pokaż komunikat użytkownikowi.

