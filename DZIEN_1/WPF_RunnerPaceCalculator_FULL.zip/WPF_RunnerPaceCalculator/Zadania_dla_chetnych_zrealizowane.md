# Zadania dla chętnych - zrealizowane w projekcie

Ten plik opisuje, gdzie w kodzie zostały zrealizowane zadania dodatkowe.

## 1. Wybór jednostki: kilometry albo mile

Zrealizowane w pliku:

- `MainWindow.xaml` - kontrolka `DistanceUnitComboBox`,
- `MainWindow.xaml.cs` - metoda `GetSelectedDistanceUnit()`,
- `Models/DistanceUnit.cs` - enum `DistanceUnit`,
- `Services/PaceCalculator.cs` - przeliczenie mil na kilometry.

## 2. Zmiana koloru wyniku

Zrealizowane w pliku:

- `MainWindow.xaml.cs` - metoda `GetBrushForPace(double pacePerKilometer)`.

Reguły:

- zielony: tempo poniżej 5:00 min/km,
- pomarańczowy: tempo 5:00-6:30 min/km,
- czerwony: tempo powyżej 6:30 min/km.

## 3. Przycisk „Wyczyść”

Zrealizowane w pliku:

- `MainWindow.xaml` - przycisk `ClearButton`,
- `MainWindow.xaml.cs` - metoda `ClearButton_Click(...)`.

## 4. Informacja: tempo rekreacyjne, treningowe, szybkie

Zrealizowane w pliku:

- `Models/PaceCategory.cs` - enum `PaceCategory`,
- `Services/PaceCalculator.cs` - metoda prywatna `GetCategory(...)`,
- `MainWindow.xaml.cs` - metoda `GetCategoryDescription(...)`.

