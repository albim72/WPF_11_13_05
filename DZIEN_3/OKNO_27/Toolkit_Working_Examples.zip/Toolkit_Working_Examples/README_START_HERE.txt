MVVM Toolkit - kompletne przyklady do uruchomienia
==================================================

W ZIP-ie sa dwa projekty:

1) Toolkit_Demo_NET8
   Glowny, rekomendowany projekt demonstracyjny.
   To czysty projekt WPF na .NET 8 z PackageReference.
   CommunityToolkit.Mvvm dziala tutaj przez source generatory.

   Otworz:
   Toolkit_Demo_NET8/Toolkit_Demo_NET8.sln

2) Toolkit_Changed_NET48_FIXED
   Wersja naprawiona pod klasyczny .NET Framework 4.8.
   Usunieto packages.config, usunieto lokalna klase ObservableObject
   i dodano CommunityToolkit.Mvvm przez PackageReference.

   Otworz:
   Toolkit_Changed_NET48_FIXED/Toolkit_Changed_NET48_FIXED.sln

Co pokazuje przyklad?
---------------------
- [ObservableProperty] generuje publiczne wlasciwosci FirstName i LastName.
- [NotifyPropertyChangedFor(nameof(FullName))] odswieza FullName po zmianie imienia lub nazwiska.
- [RelayCommand] generuje komendy ResetCommand i ClearCommand.
- TextBoxy sa zbindowane w trybie TwoWay z UpdateSourceTrigger=PropertyChanged.

Najwazniejsze:
--------------
Nie ma tutaj wlasnej klasy ObservableObject.
Uzywana jest klasa:
CommunityToolkit.Mvvm.ComponentModel.ObservableObject

Dlatego Toolkit moze poprawnie wygenerowac kod.
