using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Toolkit_Changed_NET48_FIXED.ViewModels
{
    // Klasa MUSI byc partial, bo generator CommunityToolkit dopisuje do niej kod.
    // Nie tworzymy wlasnej klasy ObservableObject. Uzywamy tej z CommunityToolkit.
    public partial class RunnerViewModel : ObservableObject
    {
        // Z tego pola Toolkit wygeneruje publiczna wlasciwosc FirstName.
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(FullName))]
        private string firstName = "Anna";

        // Z tego pola Toolkit wygeneruje publiczna wlasciwosc LastName.
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(FullName))]
        private string lastName = "Nowak";

        // FullName jest wlasciwoscia wyliczana.
        // NotifyPropertyChangedFor sprawia, ze odswieza sie po zmianie FirstName/LastName.
        public string FullName => $"{FirstName} {LastName}".Trim();

        // Toolkit wygeneruje publiczna komende ResetCommand.
        [RelayCommand]
        private void Reset()
        {
            FirstName = "Anna";
            LastName = "Nowak";
        }

        // Toolkit wygeneruje publiczna komende ClearCommand.
        [RelayCommand]
        private void Clear()
        {
            FirstName = string.Empty;
            LastName = string.Empty;
        }
    }
}
