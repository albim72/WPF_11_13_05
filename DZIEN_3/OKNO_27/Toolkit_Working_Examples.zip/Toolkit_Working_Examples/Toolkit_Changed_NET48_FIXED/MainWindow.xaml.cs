using System.Windows;
using Toolkit_Changed_NET48_FIXED.ViewModels;

namespace Toolkit_Changed_NET48_FIXED
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // DataContext laczy View z ViewModelem.
            // XAML widzi publiczne wlasciwosci wygenerowane przez CommunityToolkit.
            DataContext = new RunnerViewModel();
        }
    }
}
