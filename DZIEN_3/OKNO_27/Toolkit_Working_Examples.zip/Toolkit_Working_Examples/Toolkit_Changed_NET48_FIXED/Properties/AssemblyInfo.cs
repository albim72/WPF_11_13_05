using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Toolkit_Changed_NET48_FIXED")]
[assembly: AssemblyDescription("Working WPF MVVM Toolkit example using PackageReference")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Toolkit_Changed_NET48_FIXED")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b9ffbb0d-1da8-4c48-b10f-f05be0fa2c46")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
