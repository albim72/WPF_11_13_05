using System.Windows;

namespace Toolkit_Changed_NET48_FIXED
{
    public partial class App : Application
    {
    }
}
