using System.Windows;
using Toolkit_Demo_NET8.ViewModels;

namespace Toolkit_Demo_NET8;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        // W praktycznym MVVM DataContext wskazuje na ViewModel.
        // Widok nie liczy nic sam. Widok tylko pokazuje dane i wysyla zmiany do ViewModelu.
        DataContext = new RunnerViewModel();
    }
}
