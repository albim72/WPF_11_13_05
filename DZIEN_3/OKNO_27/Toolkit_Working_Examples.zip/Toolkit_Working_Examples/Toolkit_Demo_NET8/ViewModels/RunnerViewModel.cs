using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Toolkit_Demo_NET8.ViewModels;

// Klasa MUSI byc partial, bo generator CommunityToolkit dopisuje do niej kod.
// Dziedziczymy po ObservableObject z CommunityToolkit, a nie po wlasnej klasie.
public partial class RunnerViewModel : ObservableObject
{
    // Z tego pola Toolkit wygeneruje publiczna wlasciwosc:
    // public string FirstName { get; set; }
    // Nazwa powstaje automatycznie: firstName -> FirstName.
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(FullName))]
    private string firstName = "Anna";

    // Z tego pola Toolkit wygeneruje publiczna wlasciwosc:
    // public string LastName { get; set; }
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(FullName))]
    private string lastName = "Nowak";

    // To jest wlasciwosc wyliczana.
    // Nie ma settera, bo jej wartosc zalezy od FirstName i LastName.
    public string FullName => $"{FirstName} {LastName}".Trim();

    // Toolkit wygeneruje komende ResetCommand.
    [RelayCommand]
    private void Reset()
    {
        FirstName = "Anna";
        LastName = "Nowak";
    }

    // Toolkit wygeneruje komende ClearCommand.
    [RelayCommand]
    private void Clear()
    {
        FirstName = string.Empty;
        LastName = string.Empty;
    }
}
