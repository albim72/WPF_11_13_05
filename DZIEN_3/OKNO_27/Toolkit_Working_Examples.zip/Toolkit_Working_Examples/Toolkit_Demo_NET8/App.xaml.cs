using System.Windows;

namespace Toolkit_Demo_NET8;

public partial class App : Application
{
}
