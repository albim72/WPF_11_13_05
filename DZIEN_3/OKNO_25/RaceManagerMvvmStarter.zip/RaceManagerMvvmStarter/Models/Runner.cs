using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RaceManagerMvvmStarter.Models;

public class Runner : INotifyPropertyChanged
{
    private string _status;

    public Runner(string name, string status = "brak")
    {
        Name = name;
        _status = status;
    }

    public string Name { get; }

    public string Status
    {
        get => _status;
        set
        {
            if (_status == value) return;
            _status = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(DisplayName));
        }
    }

    public string DisplayName => $"{Name} - status: {Status}";

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
