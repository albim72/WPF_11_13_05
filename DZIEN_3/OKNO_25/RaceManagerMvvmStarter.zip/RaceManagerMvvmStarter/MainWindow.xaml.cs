using System.Windows;
using RaceManagerMvvmStarter.ViewModels;

namespace RaceManagerMvvmStarter;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
