using System;
using System.Collections.ObjectModel;
using RaceManagerMvvmStarter.Messages;

namespace RaceManagerMvvmStarter.ViewModels;

public class LogViewModel
{
    public LogViewModel()
    {
        Messages.Add("Aplikacja uruchomiona. Wybierz zawodnika lub dodaj nowego.");

        MessageBus.Subscribe<RunnerAddedMessage>(message =>
        {
            Messages.Add($"[{DateTime.Now:HH:mm:ss}] Dodano zawodnika: {message.RunnerName}");
        });

        MessageBus.Subscribe<RunnerStatusChangedMessage>(message =>
        {
            Messages.Add($"[{DateTime.Now:HH:mm:ss}] Zmieniono status: {message.RunnerName}: {message.OldStatus} -> {message.NewStatus}");
        });
    }

    public ObservableCollection<string> Messages { get; } = new();
}
