using System.Collections.ObjectModel;
using RaceManagerMvvmStarter.Models;

namespace RaceManagerMvvmStarter.ViewModels;

public class MainViewModel
{
    public MainViewModel()
    {
        ObservableCollection<Runner> runners = new()
        {
            new Runner("Anna Nowak"),
            new Runner("Jan Kowalski"),
            new Runner("Piotr Zieliński")
        };

        Log = new LogViewModel();
        Form = new RunnerFormViewModel(runners);
        List = new RunnerListViewModel(runners);
    }

    public RunnerFormViewModel Form { get; }
    public RunnerListViewModel List { get; }
    public LogViewModel Log { get; }
}
