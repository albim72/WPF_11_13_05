using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RaceManagerMvvmStarter.Commands;
using RaceManagerMvvmStarter.Messages;
using RaceManagerMvvmStarter.Models;

namespace RaceManagerMvvmStarter.ViewModels;

public class RunnerFormViewModel : INotifyPropertyChanged
{
    private readonly ObservableCollection<Runner> _runners;
    private readonly RelayCommand _addRunnerCommand;
    private string _runnerName = "Maria Wiśniewska";

    public RunnerFormViewModel(ObservableCollection<Runner> runners)
    {
        _runners = runners;
        _addRunnerCommand = new RelayCommand(_ => AddRunner(), _ => CanAddRunner());
    }

    public string RunnerName
    {
        get => _runnerName;
        set
        {
            if (_runnerName == value) return;
            _runnerName = value;
            OnPropertyChanged();
            _addRunnerCommand.RaiseCanExecuteChanged();
        }
    }

    public ICommand AddRunnerCommand => _addRunnerCommand;

    private bool CanAddRunner()
    {
        // Wersja bazowa: blokada tylko dla pustego tekstu.
        // Zadanie dla kursantów: dopisać min. 3 znaki i blokadę cyfr.
        return !string.IsNullOrWhiteSpace(RunnerName);
    }

    private void AddRunner()
    {
        string name = RunnerName.Trim();
        _runners.Add(new Runner(name));
        MessageBus.Send(new RunnerAddedMessage(name));
        RunnerName = string.Empty;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
