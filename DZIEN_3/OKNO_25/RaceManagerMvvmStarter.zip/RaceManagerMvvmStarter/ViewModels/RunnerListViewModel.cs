using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RaceManagerMvvmStarter.Commands;
using RaceManagerMvvmStarter.Messages;
using RaceManagerMvvmStarter.Models;

namespace RaceManagerMvvmStarter.ViewModels;

public class RunnerListViewModel : INotifyPropertyChanged
{
    private readonly RelayCommand _setStatusCommand;
    private Runner? _selectedRunner;

    public RunnerListViewModel(ObservableCollection<Runner> runners)
    {
        Runners = runners;
        _setStatusCommand = new RelayCommand(SetStatus, _ => SelectedRunner != null);
    }

    public ObservableCollection<Runner> Runners { get; }

    public Runner? SelectedRunner
    {
        get => _selectedRunner;
        set
        {
            if (_selectedRunner == value) return;
            _selectedRunner = value;
            OnPropertyChanged();
            _setStatusCommand.RaiseCanExecuteChanged();
        }
    }

    public ICommand SetStatusCommand => _setStatusCommand;

    private void SetStatus(object? parameter)
    {
        if (SelectedRunner == null || parameter is not string newStatus)
        {
            return;
        }

        string oldStatus = SelectedRunner.Status;
        SelectedRunner.Status = newStatus;

        MessageBus.Send(new RunnerStatusChangedMessage(
            SelectedRunner.Name,
            oldStatus,
            newStatus));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
