using System;
using System.Collections.Generic;
using System.Linq;

namespace RaceManagerMvvmStarter.Messages;

public static class MessageBus
{
    private static readonly Dictionary<Type, List<Delegate>> Handlers = new();

    public static void Subscribe<TMessage>(Action<TMessage> handler)
    {
        Type messageType = typeof(TMessage);

        if (!Handlers.ContainsKey(messageType))
        {
            Handlers[messageType] = new List<Delegate>();
        }

        Handlers[messageType].Add(handler);
    }

    public static void Send<TMessage>(TMessage message)
    {
        Type messageType = typeof(TMessage);

        if (!Handlers.TryGetValue(messageType, out List<Delegate>? handlers))
        {
            return;
        }

        foreach (Action<TMessage> handler in handlers.OfType<Action<TMessage>>().ToArray())
        {
            handler(message);
        }
    }
}
