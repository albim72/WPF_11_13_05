namespace RaceManagerMvvmStarter.Messages;

public class RunnerAddedMessage
{
    public RunnerAddedMessage(string runnerName)
    {
        RunnerName = runnerName;
    }

    public string RunnerName { get; }
}
