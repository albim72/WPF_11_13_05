namespace RaceManagerMvvmStarter.Messages;

public class RunnerStatusChangedMessage
{
    public RunnerStatusChangedMessage(string runnerName, string oldStatus, string newStatus)
    {
        RunnerName = runnerName;
        OldStatus = oldStatus;
        NewStatus = newStatus;
    }

    public string RunnerName { get; }
    public string OldStatus { get; }
    public string NewStatus { get; }
}
