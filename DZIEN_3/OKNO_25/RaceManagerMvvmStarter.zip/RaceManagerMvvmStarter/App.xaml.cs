using System.Windows;

namespace RaceManagerMvvmStarter;

public partial class App : Application
{
}
