RaceManagerMvvmStarter
======================

Działający projekt startowy do dnia 3 szkolenia WPF / MVVM.

Jak uruchomić:
1. Rozpakuj ZIP.
2. Otwórz folder RaceManagerMvvmStarter w Visual Studio 2022.
3. Upewnij się, że masz .NET 8 SDK.
4. Uruchom projekt F5.

Projekt pokazuje:
- MVVM
- DataContext
- Binding
- ICommand / RelayCommand
- CanExecute
- SelectedItem
- CommandParameter
- ObservableCollection
- MessageBus i komunikaty między ViewModelami

Zadanie dla kursantów znajduje się w pliku DOCX dołączonym osobno.
