using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RaceManagerMvvmComplete.Models;

// ELEMENT ZADANIA 1: Model aplikacji.
// Model przechowuje dane zawodnika i nie zna kontrolek WPF.
public class Runner : INotifyPropertyChanged
{
    private string _status;

    public Runner(string name, string status = "brak")
    {
        Name = name;
        _status = status;
    }

    public string Name { get; }

    public string Status
    {
        get => _status;
        set
        {
            if (_status == value) return;

            _status = value;

            // ELEMENT ZADANIA 4: Po zmianie statusu odświeżamy sam Status.
            OnPropertyChanged();

            // ELEMENT ZADANIA 4: DisplayName zależy od Status,
            // dlatego trzeba powiadomić widok również o zmianie DisplayName.
            OnPropertyChanged(nameof(DisplayName));
        }
    }

    // ELEMENT ZADANIA 1: Właściwość obliczana używana przez widok i logikę prezentacji.
    public string DisplayName => $"{Name} - status: {Status}";

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
