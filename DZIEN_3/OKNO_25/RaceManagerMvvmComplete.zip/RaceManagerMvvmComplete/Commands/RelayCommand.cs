using System;
using System.Windows.Input;

namespace RaceManagerMvvmComplete.Commands;

// ELEMENT ZADANIA 1-5: Uniwersalna komenda MVVM.
// Dzięki tej klasie Button w XAML używa Command="{Binding ...}",
// a nie klasycznego zdarzenia Click w MainWindow.xaml.cs.
public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    private readonly Predicate<object?>? _canExecute;

    public RelayCommand(Action<object?> execute, Predicate<object?>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    // ELEMENT ZADANIA 3: CanExecute decyduje, czy przycisk jest aktywny.
    // Jeśli warunek nie został przekazany, komenda domyślnie jest aktywna.
    public bool CanExecute(object? parameter)
    {
        return _canExecute?.Invoke(parameter) ?? true;
    }

    // ELEMENT ZADANIA 2: Execute uruchamia akcję przypisaną do komendy.
    public void Execute(object? parameter)
    {
        _execute(parameter);
    }

    public event EventHandler? CanExecuteChanged;

    // ELEMENT ZADANIA 3 I 4: Wywołujemy tę metodę, gdy zmienił się stan danych,
    // od którego zależy aktywność przycisku, np. tekst w formularzu lub SelectedRunner.
    public void RaiseCanExecuteChanged()
    {
        CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}
