using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RaceManagerMvvmComplete.Commands;
using RaceManagerMvvmComplete.Messages;
using RaceManagerMvvmComplete.Models;

namespace RaceManagerMvvmComplete.ViewModels;

// ELEMENT ZADANIA 1: ViewModel formularza dodawania zawodnika.
// ViewModel przechowuje stan formularza i komendę, ale nie zna kontrolek WPF.
public class RunnerFormViewModel : INotifyPropertyChanged
{
    private readonly ObservableCollection<Runner> _runners;
    private readonly RelayCommand _addRunnerCommand;
    private string _runnerName = "Maria Wiśniewska";

    public RunnerFormViewModel(ObservableCollection<Runner> runners)
    {
        _runners = runners;

        // ELEMENT ZADANIA 2 I 3: Komenda dodawania zawodnika.
        // Pierwszy argument mówi, co wykonać.
        // Drugi argument mówi, kiedy przycisk może być aktywny.
        _addRunnerCommand = new RelayCommand(_ => AddRunner(), _ => CanAddRunner());
    }

    // ELEMENT ZADANIA 3: TextBox w XAML jest powiązany z tą właściwością przez Binding TwoWay.
    public string RunnerName
    {
        get => _runnerName;
        set
        {
            if (_runnerName == value) return;

            _runnerName = value;

            // ELEMENT ZADANIA 3: Odświeżenie tekstu w TextBoxie i innych miejscach widoku.
            OnPropertyChanged();

            // ZADANIE DLA CHĘTNYCH: Dynamiczny komunikat walidacyjny pod formularzem.
            OnPropertyChanged(nameof(ValidationMessage));

            // ELEMENT ZADANIA 3: Po każdej zmianie tekstu sprawdzamy ponownie CanExecute,
            // aby przycisk Dodaj zawodnika sam się blokował lub odblokowywał.
            _addRunnerCommand.RaiseCanExecuteChanged();
        }
    }

    // ZADANIE DLA CHĘTNYCH: Komunikat pokazujący, dlaczego przycisk jest zablokowany.
    public string ValidationMessage
    {
        get
        {
            string name = RunnerName.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                return "Wpisz imię i nazwisko zawodnika.";
            }

            if (name.Length < 3)
            {
                return "Tekst musi mieć co najmniej 3 znaki.";
            }

            if (name.Any(char.IsDigit))
            {
                return "Nazwa zawodnika nie może zawierać cyfr.";
            }

            return "Dane poprawne, można dodać zawodnika.";
        }
    }

    public ICommand AddRunnerCommand => _addRunnerCommand;

    private bool CanAddRunner()
    {
        string name = RunnerName.Trim();

        // ELEMENT ZADANIA 3: Pełna walidacja CanExecute.
        // Przycisk jest aktywny tylko wtedy, gdy tekst:
        // 1. nie jest pusty,
        // 2. ma minimum 3 znaki,
        // 3. nie zawiera żadnej cyfry.
        if (string.IsNullOrWhiteSpace(name)) return false;
        if (name.Length < 3) return false;
        if (name.Any(char.IsDigit)) return false;

        return true;
    }

    private void AddRunner()
    {
        string name = RunnerName.Trim();

        // ELEMENT ZADANIA 5: Dodajemy zawodnika do wspólnej ObservableCollection.
        _runners.Add(new Runner(name));

        // ELEMENT ZADANIA 5: Wysyłamy komunikat do logu.
        // Formularz nie dopisuje tekstu bezpośrednio do LogViewModel.
        MessageBus.Send(new RunnerAddedMessage(name));

        // ELEMENT ZADANIA 3: Po dodaniu czyścimy TextBox.
        // Setter RunnerName zablokuje przycisk, bo tekst stanie się pusty.
        RunnerName = string.Empty;
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
