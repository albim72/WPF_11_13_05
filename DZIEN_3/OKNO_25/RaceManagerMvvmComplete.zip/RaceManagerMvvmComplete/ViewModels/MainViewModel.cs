using System.Collections.ObjectModel;
using RaceManagerMvvmComplete.Models;

namespace RaceManagerMvvmComplete.ViewModels;

// ELEMENT ZADANIA 1 I 5: Główny ViewModel okna.
// Łączy mniejsze ViewModele: formularz, listę i log.
// Widok MainWindow.xaml ustawia DataContext na MainViewModel.
public class MainViewModel
{
    public MainViewModel()
    {
        // ELEMENT ZADANIA 5: Wspólna kolekcja zawodników przekazywana do formularza i listy.
        // Dzięki temu dodanie zawodnika w RunnerFormViewModel od razu widać w RunnerListViewModel.
        ObservableCollection<Runner> runners = new()
        {
            new Runner("Anna Nowak"),
            new Runner("Jan Kowalski"),
            new Runner("Piotr Zieliński")
        };

        // ELEMENT ZADANIA 5: Log tworzony jako pierwszy, aby od razu subskrybował komunikaty.
        Log = new LogViewModel();

        // ELEMENT ZADANIA 1: Osobne ViewModele odpowiadają za osobne części ekranu.
        Form = new RunnerFormViewModel(runners);
        List = new RunnerListViewModel(runners);
    }

    public RunnerFormViewModel Form { get; }
    public RunnerListViewModel List { get; }
    public LogViewModel Log { get; }
}
