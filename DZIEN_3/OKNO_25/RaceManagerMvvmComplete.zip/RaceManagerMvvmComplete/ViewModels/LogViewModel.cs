using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RaceManagerMvvmComplete.Commands;
using RaceManagerMvvmComplete.Messages;

namespace RaceManagerMvvmComplete.ViewModels;

// ELEMENT ZADANIA 5: ViewModel logu.
// Odbiera komunikaty z innych ViewModeli i pokazuje je w ListBoxie.
public class LogViewModel : INotifyPropertyChanged
{
    private readonly RelayCommand _clearLogCommand;

    public LogViewModel()
    {
        _clearLogCommand = new RelayCommand(_ => MessageBus.Send(new LogClearedMessage()), _ => Messages.Count > 0);

        // ZADANIE DLA CHĘTNYCH: Licznik komunikatów i aktywność przycisku Czyszczenia logu
        // odświeżają się po każdej zmianie kolekcji Messages.
        Messages.CollectionChanged += MessagesOnCollectionChanged;

        // ELEMENT ZADANIA 5: Subskrypcja komunikatu o dodaniu zawodnika.
        MessageBus.Subscribe<RunnerAddedMessage>(message =>
        {
            AddLogMessage($"Dodano zawodnika: {message.RunnerName}");
        });

        // ELEMENT ZADANIA 5: Subskrypcja komunikatu o zmianie statusu.
        MessageBus.Subscribe<RunnerStatusChangedMessage>(message =>
        {
            AddLogMessage($"Zmieniono status: {message.RunnerName}: {message.OldStatus} -> {message.NewStatus}");
        });

        // ZADANIE DLA CHĘTNYCH: Subskrypcja komunikatu o usunięciu zawodnika.
        MessageBus.Subscribe<RunnerRemovedMessage>(message =>
        {
            AddLogMessage($"Usunięto zawodnika: {message.RunnerName}");
        });

        // ZADANIE DLA CHĘTNYCH: Czyszczenie logu również przechodzi przez MessageBus.
        MessageBus.Subscribe<LogClearedMessage>(_ =>
        {
            Messages.Clear();
            AddLogMessage("Log wyczyszczony.");
        });

        AddLogMessage("Aplikacja uruchomiona. Wybierz zawodnika albo dodaj nowego.");
    }

    public ObservableCollection<string> Messages { get; } = new();

    // ZADANIE DLA CHĘTNYCH: Licznik komunikatów wyświetlany w XAML.
    public int MessageCount => Messages.Count;

    // ZADANIE DLA CHĘTNYCH: Komenda czyszczenia logu.
    public ICommand ClearLogCommand => _clearLogCommand;

    private void AddLogMessage(string text)
    {
        // ELEMENT ZADANIA 5 I ZADANIE DLA CHĘTNYCH: Każdy komunikat dostaje godzinę.
        Messages.Add($"[{DateTime.Now:HH:mm:ss}] {text}");
    }

    private void MessagesOnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        OnPropertyChanged(nameof(MessageCount));
        _clearLogCommand.RaiseCanExecuteChanged();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
