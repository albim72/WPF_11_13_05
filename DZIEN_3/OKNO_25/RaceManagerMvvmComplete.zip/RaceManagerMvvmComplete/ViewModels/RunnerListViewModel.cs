using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RaceManagerMvvmComplete.Commands;
using RaceManagerMvvmComplete.Messages;
using RaceManagerMvvmComplete.Models;

namespace RaceManagerMvvmComplete.ViewModels;

// ELEMENT ZADANIA 1: ViewModel odpowiedzialny za listę zawodników i operacje na wybranym zawodniku.
public class RunnerListViewModel : INotifyPropertyChanged
{
    private readonly RelayCommand _setStatusCommand;
    private readonly RelayCommand _removeRunnerCommand;
    private Runner? _selectedRunner;

    public RunnerListViewModel(ObservableCollection<Runner> runners)
    {
        Runners = runners;

        // ELEMENT ZADANIA 4: Jedna komenda zmiany statusu obsługuje wiele przycisków.
        // Konkretny status przychodzi z CommandParameter w XAML.
        _setStatusCommand = new RelayCommand(SetStatus, _ => SelectedRunner != null);

        // ZADANIE DLA CHĘTNYCH: Usuwanie wybranego zawodnika.
        _removeRunnerCommand = new RelayCommand(_ => RemoveSelectedRunner(), _ => SelectedRunner != null);

        // ZADANIE DLA CHĘTNYCH: Licznik zawodników odświeża się po zmianie kolekcji.
        Runners.CollectionChanged += RunnersOnCollectionChanged;
    }

    // ELEMENT ZADANIA 3 I 5: ObservableCollection automatycznie odświeża ListBox po dodaniu lub usunięciu elementu.
    public ObservableCollection<Runner> Runners { get; }

    // ZADANIE DLA CHĘTNYCH: Licznik zawodników pokazywany w XAML.
    public int RunnerCount => Runners.Count;

    // ELEMENT ZADANIA 4: SelectedItem z ListBoxa zapisuje wybrany obiekt do tej właściwości.
    public Runner? SelectedRunner
    {
        get => _selectedRunner;
        set
        {
            if (_selectedRunner == value) return;

            _selectedRunner = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedRunnerText));

            // ELEMENT ZADANIA 4: Po wyborze zawodnika przyciski statusu i usuwania mają się aktywować.
            _setStatusCommand.RaiseCanExecuteChanged();
            _removeRunnerCommand.RaiseCanExecuteChanged();
        }
    }

    // ELEMENT ZADANIA 4: Tekst pomocniczy wyświetlany pod listą.
    public string SelectedRunnerText => SelectedRunner?.DisplayName ?? "brak wybranego zawodnika";

    public ICommand SetStatusCommand => _setStatusCommand;
    public ICommand RemoveRunnerCommand => _removeRunnerCommand;

    private void SetStatus(object? parameter)
    {
        if (SelectedRunner == null || parameter is not string newStatus)
        {
            return;
        }

        string oldStatus = SelectedRunner.Status;

        // ELEMENT ZADANIA 4: CommandParameter z przycisku trafia tutaj jako newStatus.
        // Obsługiwane statusy: OK, WARNING, DNF, DNS, brak.
        SelectedRunner.Status = newStatus;

        // ELEMENT ZADANIA 4: Po zmianie statusu aktualizujemy tekst wybranego zawodnika.
        OnPropertyChanged(nameof(SelectedRunnerText));

        // ELEMENT ZADANIA 5: Wysyłamy komunikat do LogViewModel.
        MessageBus.Send(new RunnerStatusChangedMessage(
            SelectedRunner.Name,
            oldStatus,
            newStatus));
    }

    private void RemoveSelectedRunner()
    {
        if (SelectedRunner == null)
        {
            return;
        }

        string removedName = SelectedRunner.Name;

        // ZADANIE DLA CHĘTNYCH: Usunięcie aktualnie zaznaczonego zawodnika z kolekcji.
        Runners.Remove(SelectedRunner);

        // Po usunięciu czyścimy zaznaczenie, aby przyciski się zablokowały.
        SelectedRunner = null;

        // ZADANIE DLA CHĘTNYCH: Informacja o usunięciu trafia do logu przez MessageBus.
        MessageBus.Send(new RunnerRemovedMessage(removedName));
    }

    private void RunnersOnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        // ZADANIE DLA CHĘTNYCH: Odświeżenie licznika zawodników po dodaniu lub usunięciu.
        OnPropertyChanged(nameof(RunnerCount));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
