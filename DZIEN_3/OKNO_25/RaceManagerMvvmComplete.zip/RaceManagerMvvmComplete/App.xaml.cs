using System.Windows;

namespace RaceManagerMvvmComplete;

public partial class App : Application
{
}
