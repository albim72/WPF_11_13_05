RaceManagerMvvmComplete
=======================

Pełne rozwiązanie projektu WPF / MVVM do dnia 3 szkolenia.

Projekt zawiera zrealizowane elementy zadań 1-5 oraz funkcje dla chętnych.

Zrealizowane elementy podstawowe:
1. MVVM: Model, View, ViewModel.
2. DataContext i Binding.
3. ICommand oraz RelayCommand.
4. CanExecute i blokowanie przycisków.
5. TextBox z Mode=TwoWay i UpdateSourceTrigger=PropertyChanged.
6. ObservableCollection i ListBox.
7. SelectedItem oraz SelectedRunner.
8. CommandParameter dla statusów.
9. MessageBus i komunikacja między ViewModelami.
10. Brak logiki biznesowej w MainWindow.xaml.cs.

Zrealizowane elementy dla chętnych:
1. Walidacja: brak pustego pola, minimum 3 znaki, blokada cyfr.
2. Dynamiczny komunikat walidacyjny.
3. Licznik zawodników.
4. Licznik komunikatów w logu.
5. Usuwanie wybranego zawodnika.
6. Status DNS.
7. Czyszczenie logu.
8. Kolorowanie statusów przez DataTrigger.
9. Komunikaty logu z godziną.

Jak uruchomić:
1. Rozpakuj ZIP.
2. Otwórz RaceManagerMvvmComplete.sln w Visual Studio 2022.
3. Upewnij się, że masz .NET 8 SDK.
4. Uruchom projekt klawiszem F5.

Komentarze w kodzie:
W plikach .cs i MainWindow.xaml są komentarze oznaczone jako:
- ELEMENT ZADANIA 1
- ELEMENT ZADANIA 2
- ELEMENT ZADANIA 3
- ELEMENT ZADANIA 4
- ELEMENT ZADANIA 5
- ZADANIE DLA CHĘTNYCH

Dzięki temu kursanci widzą dokładnie, gdzie w kodzie zrealizowano dany fragment zadania.
