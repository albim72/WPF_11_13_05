using System.Windows;
using RaceManagerMvvmComplete.ViewModels;

namespace RaceManagerMvvmComplete;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        // ELEMENT ZADANIA 1: Jedyne zadanie code-behind.
        // Ustawiamy DataContext na MainViewModel.
        // Cała logika aplikacji znajduje się w ViewModelach, nie w MainWindow.xaml.cs.
        DataContext = new MainViewModel();
    }
}
