namespace RaceManagerMvvmComplete.Messages;

// ZADANIE DLA CHĘTNYCH: Komunikat informujący o wyczyszczeniu logu.
public class LogClearedMessage
{
}
