namespace RaceManagerMvvmComplete.Messages;

// ZADANIE DLA CHĘTNYCH: Komunikat wysyłany po usunięciu zawodnika.
public class RunnerRemovedMessage
{
    public RunnerRemovedMessage(string runnerName)
    {
        RunnerName = runnerName;
    }

    public string RunnerName { get; }
}
