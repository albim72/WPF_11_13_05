using System;
using System.Collections.Generic;
using System.Linq;

namespace RaceManagerMvvmComplete.Messages;

// ELEMENT ZADANIA 5: Prosty MessageBus do komunikacji między ViewModelami.
// ViewModel formularza, listy i logu nie muszą znać siebie nawzajem.
// Wysyłają i odbierają komunikaty przez wspólnego pośrednika.
public static class MessageBus
{
    private static readonly Dictionary<Type, List<Delegate>> Handlers = new();

    // ELEMENT ZADANIA 5: Subskrypcja komunikatu.
    // LogViewModel zapisuje się tutaj jako odbiorca komunikatów.
    public static void Subscribe<TMessage>(Action<TMessage> handler)
    {
        Type messageType = typeof(TMessage);

        if (!Handlers.ContainsKey(messageType))
        {
            Handlers[messageType] = new List<Delegate>();
        }

        Handlers[messageType].Add(handler);
    }

    // ELEMENT ZADANIA 5: Wysłanie komunikatu do wszystkich odbiorców danego typu.
    public static void Send<TMessage>(TMessage message)
    {
        Type messageType = typeof(TMessage);

        if (!Handlers.TryGetValue(messageType, out List<Delegate>? handlers))
        {
            return;
        }

        foreach (Action<TMessage> handler in handlers.OfType<Action<TMessage>>().ToArray())
        {
            handler(message);
        }
    }
}
