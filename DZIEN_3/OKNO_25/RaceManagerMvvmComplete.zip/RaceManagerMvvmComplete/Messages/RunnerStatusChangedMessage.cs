namespace RaceManagerMvvmComplete.Messages;

// ELEMENT ZADANIA 5: Komunikat wysyłany po zmianie statusu zawodnika.
public class RunnerStatusChangedMessage
{
    public RunnerStatusChangedMessage(string runnerName, string oldStatus, string newStatus)
    {
        RunnerName = runnerName;
        OldStatus = oldStatus;
        NewStatus = newStatus;
    }

    public string RunnerName { get; }
    public string OldStatus { get; }
    public string NewStatus { get; }
}
