namespace RaceManagerMvvmComplete.Messages;

// ELEMENT ZADANIA 5: Komunikat wysyłany po dodaniu zawodnika.
public class RunnerAddedMessage
{
    public RunnerAddedMessage(string runnerName)
    {
        RunnerName = runnerName;
    }

    public string RunnerName { get; }
}
